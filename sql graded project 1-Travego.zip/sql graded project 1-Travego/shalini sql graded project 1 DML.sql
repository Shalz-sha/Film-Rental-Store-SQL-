/* 2) a.How many female passengers traveled a minimum distance of 600 KMs? */
use travego;
/* use function for use a database travego */
select gender,count(*) as Count_Female_Passengers from passenger 
where gender = 'F' and distance >=600;
 /*select function => used to return what are the columns needed count(*) => used to count entire data of gender , 
 as => function used to give a name here as we need number of female passengers travelled at minimum distance of 600 we give a name as count_female_passengers
 from function => used to get a data from table by mentioning table name, where => where function holds a condition ,
 and function => used  to get multiple condition it returns value if both the conditions are true. */


/* b) Write a query to display the passenger details whose travel distance is greater than 500 and
who are traveling in a sleeper bus.*/
select * from passenger 
/* passenger table is selected */
where distance > 500 and bus_type = 'sleeper';
/* in where funtion two conditions are given one is to get distance values which is greater than 500 and another 
condition is to get bus_type ='sleeper' helps to get a data distance more than 500 where sleeper bus_type */

/* c) Select passenger names whose names start with the character 'S' */
select passenger_name as passenger_name_S from passenger 
/* passenger_name column is selected and named as passenger_name_s */
where passenger_name like 's%';
/* in where condition, to get a s starting passenger_name with using like funcion */

/* d) Calculate the price charged for each passenger, displaying the Passenger name, Boarding City,
Destination City, Bus type, and Price in the output. */
select passenger.passenger_name,passenger.boarding_city,passenger.destination_city,passenger.bus_type,price.price 
/*requiring columns are selected using select function, from function => used to get a data from table,
where functin=> as used to get price in a output comparing price in passenger and price table */
from passenger,price where passenger.distance = price.distance;

/* e) What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in
a bus? */
SELECT p.passenger_name,pr.price from passenger p,price pr
 where pr.distance >=1000 and pr.bus_type = 'Sitting';
 /* passenger_name and price from passenger and price table, where conditon used to get distance more than and 
 equal to 1000 and bus_type ='sitting' */
 
 /* f)what will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji? */
 select*from passenger;
select*from price;
select bus_type,price from price where distance=(select distance from passenger where passenger_name='Pallavi');
/* bus_type and price column are selected, from function=> used to get value from price , 
where function => get a distance value from passenger respect to name 'pallavi' */


/* g) Alter the column category with the value "Non-AC" where the Bus_Type is sleeper */
select*from passenger;
update passenger
set category='Non-Ac'
where  bus_type='Sleeper';

/* update function => give a passenger column, set function=> holds bus_type ='sleeper',
where condition holds category which have 'non-ac and passenger_id */

/* h) Delete an entry from the table where the passenger name is Piyush and commit this change in
the database */
delete from passenger 
where passenger_name = 'Piyush';
commit;
/* delete function is used to delete a table, where function holds a conditon passenger_name='piyush',
commit function => fix this change in databases */

/* i) Truncate the table passenger and comment on the number of rows in the table (explain if
required). */
truncate table passenger;
/* truncate function delete a rows in table */

/* j) Delete the table passenger from the database */
drop table passenger;
